// Placeholder for potential UI injection
console.log("VRC Worlds Manager Helper loaded");
